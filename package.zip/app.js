var express = require('express');
var app = express();
var path = require('path');
var fs = require('fs');
var bodyParser = require('body-parser');
var logger = require('morgan');
const helmet = require('helmet');
var compression = require('compression');
var accessLogStream = fs.createWriteStream(path.join(__dirname, 'logs/access.log'), { flags: 'a' })
const log = require('simple-node-logger').createSimpleLogger('logs/commands.log');
var Datastore = require('nedb')
    , db = new Datastore({ filename: 'data/projetos.db', autoload: true });
app.use(express.static('bower_components'));
app.use(express.static('node_modules'));
app.use(express.static('js'));
app.use(bodyParser.urlencoded({ extended: false }))
app.use(compression());
app.use(logger('combined', { stream: accessLogStream }));
app.use(helmet());

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.get('/criarsala', function (req, res) {

    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1;
    var yyyy = today.getFullYear();
    var host = 'http://10.1.2.32';
    var port = Math.floor((Math.random() * 10000) + 41050);
    req.query.autor = req.query.autor.replace(/[^a-zA-Z]/g, "");

    var name = `${req.query.autor}-${req.query.os}-${dd}-${mm}-${yyyy}`;
    var folder = 'projetos/' + `${req.query.autor}-${req.query.os}-${dd}-${mm}-${yyyy}`;
    const exec = require("child_process").execSync;

    //verificar por branch
    //atualizar sala

    var comando = 'rm -f -r -d ' + folder;
    log.info(comando);
    exec(comando, (error, stdout, stderr) => {
        if (stderr) log.error(stderr);
        log.error(error);
        log.info(stdout);
        log.error(stderr);
    })

    var comando = `git clone -b ${req.query.branch} ${req.query.projeto} ${folder}`;
    log.info(comando);
    exec(comando, (error, stdout, stderr) => {
        if (stderr) log.error(stderr);
        log.error(error);
        log.info(stdout);
        log.error(stderr);
    })

    var comando = `cp -R -n /Public/ /servicos/Salas/${folder}`;
    log.info(comando);
    exec(comando, (error, stdout, stderr) => {
        if (stderr) log.error(stderr);
        log.error(error);
        log.info(stdout);
        log.error(stderr);
    })

    comando = `docker run --name ${name} -p ${port}:80 -d -v /servicos/Salas/${folder}:/www renanrosa/webvendas`
    log.info(comando);
    exec(comando, (error, stdout, stderr) => {
        if (stderr) log.info(stderr);
        log.info(error);
        log.info(stdout);
        log.info(stderr);
    })

    db.insert(req.query, function (err, newDoc) {   
        
    res.send(`${host}:${port}`);
    });

});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/index.html'));
});

app.listen(3000);
