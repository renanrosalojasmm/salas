var app = angular.module('salas', []);

app.controller('mainController', function ($scope, $http, clipboard) {

    $scope.criarSala = function () {
        console.log('testes');
    }

});